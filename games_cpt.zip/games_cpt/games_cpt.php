<?php 
/*
Plugin Name: Games Custom Post Type
Description: Declares a simple 'Games' custom post type, as well as its associated taxonomy and metabox
Version:     1.0.0
Author:      vincentdubroeucq.com
Author URI:  https://vincentdubroeucq.com/
Text Domain: games
Domain Path: /languages
License:     GPL2
*/


add_action( 'plugins_loaded', 'games_text_domain' );
/**
 * Load our text domain
 */
function games_text_domain() {
    load_plugin_textdomain( 'games', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}


register_activation_hook( __FILE__, 'games_activation' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
/**
 * Register our activation function
 */
function games_activation(){
    games_register_taxonomy();
    games_register_post_type();
    flush_rewrite_rules();
}


add_action( 'init', 'games_register_taxonomy' );
/**
 * Registers our custom post type
 */
function games_register_taxonomy(){

    $platform_args = array(
        'labels'      => array(
            'name'                  => __( 'Platforms', 'games' ),
            'singular_name'         => __( 'Platform', 'games' ),
            'search_items'          => __( 'Search Platforms', 'games' ),
            'popular_items'         => __( 'Popular Platforms', 'games' ),
            'all_items'             => __( 'All Platforms', 'games' ),
            'edit_item'             => __( 'Edit Platform', 'games' ),
            'view_item'             => __( 'Edit Platform', 'games' ),
            'update_item'           => __( 'Update Platform', 'games' ),
            'add_new_item'          => __( 'Add New Platform', 'games' ),
            'new_item_name'         => __( 'New Platform Name', 'games' ),
            'separate_items_with_commas' => __( 'Seperate Platforms with Commas', 'games' ),
            'add_or_remove_items'   => __( 'Add/Remove Platform', 'games' ),
            'choose_from_most_used' => __( 'Choose from the most used Platforms', 'games' ),
            'not_found'             => __( 'No Platform found.', 'games' ),
            'no_terms'              => __( 'No Platform.', 'games' ),
        ),
        'description' => __( 'Used to indicate what platform the game is available on.', 'games' ),
        'public'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    );

    $year_args = array(
        'labels'      => array(
            'name'                  => __( 'Release Years', 'games' ),
            'singular_name'         => __( 'Release Year', 'games' ),
            'search_items'          => __( 'Search Release Years', 'games' ),
            'popular_items'         => __( 'Popular Release Years', 'games' ),
            'all_items'             => __( 'All Release Years', 'games' ),
            'edit_item'             => __( 'Edit Release Year', 'games' ),
            'view_item'             => __( 'Edit Release Year', 'games' ),
            'update_item'           => __( 'Update Release Year', 'games' ),
            'add_new_item'          => __( 'Add New Release Year', 'games' ),
            'new_item_name'         => __( 'New Release Year', 'games' ),
            'separate_items_with_commas' => __( 'Seperate Release Years with Commas', 'games' ),
            'add_or_remove_items'   => __( 'Add/Remove Release Year', 'games' ),
            'choose_from_most_used' => __( 'Choose from the most used release year', 'games' ),
            'not_found'             => __( 'No release year found.', 'games' ),
            'no_terms'              => __( 'No release year.', 'games' ),
        ),
        'hierarchical'      => false,
        'description'       => __( 'Used to indicate the release year of the game.', 'games' ),
        'public'            => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    );

    register_taxonomy( 'platform', 'game', $platform_args );
    register_taxonomy( 'release-year', 'game', $year_args );
}


add_action( 'init', 'games_register_post_type' );
/**
 * Registers our custom post type
 */
function games_register_post_type(){
    
    $labels = array(
        'name'                  => _x( 'Games', 'Post type general name', 'games' ),
        'singular_name'         => _x( 'Game', 'Post type singular name', 'games' ),
        'menu_name'             => _x( 'Games', 'Admin Menu text', 'games' ),
        'name_admin_bar'        => _x( 'Game', 'Add New on Toolbar', 'games' ),
        'add_new'               => __( 'Add New', 'games' ),
        'add_new_item'          => __( 'Add New Game', 'games' ),
        'new_item'              => __( 'New Game', 'games' ),
        'edit_item'             => __( 'Edit Game', 'games' ),
        'view_item'             => __( 'View Game', 'games' ),
        'all_items'             => __( 'All Games', 'games' ),
        'search_items'          => __( 'Search Games', 'games' ),
        'parent_item_colon'     => __( 'Parent Games:', 'games' ),
        'not_found'             => __( 'No Games found.', 'games' ),
        'not_found_in_trash'    => __( 'No Games found in Trash.', 'games' ),
        'archives'              => _x( 'Game archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'games' ),
        'insert_into_item'      => _x( 'Insert into Game', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'games' ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Game', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'games' ),
        'filter_items_list'     => _x( 'Filter Games list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'games' ),
        'items_list_navigation' => _x( 'Games list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'games' ),
        'items_list'            => _x( 'Games list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'games' ),
    );
    
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'My favorite games', 'games' ),
        'public'             => true,
        'hierarchical'       => false,
        'register_meta_box_cb' => 'games_metabox',
        'taxonomies'         => array( 'platform', 'release-year' ),
        'has_archive'        => true,
        'menu_icon'          => 'dashicons-smiley',
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
        'show_in_rest'       => true,
    );
    
    register_post_type( 'game', $args );
}


/**
 * The callback to register the metabox on the Game edit post screen.
 */
function games_metabox(){
    add_meta_box( 'game_metabox', __( 'Game Wiki URL', 'games' ), 'games_metabox_display', 'game', 'side', 'default' );
}

/**
 * The callback to display the metabox on the Game edit post screen.
 */
function games_metabox_display( $post ){
    
    // Create a nonce for security
    wp_nonce_field( 'games_action', 'games_nonce' );

    // Retrieve website's URL
    $url  = get_post_meta( $post->ID, 'game_url', true ) ? get_post_meta( $post->ID, 'game_url', true ) : '';
    ?>
        <p>
            <label for="game_url" class="screen-reader-text"><?php esc_html_e( 'Enter the game Wiki url', 'games' ); ?></label>
            <input type="url" name="game_url" value="<?php echo esc_url( $url ); ?>" />
        </p>
    <?php

}


function games_save_metabox( $post_id ) {
 
    if ( ! isset( $_POST['games_nonce'] ) ){
        return;
    }

    if ( ! wp_verify_nonce( $_POST['games_nonce'], 'games_action' ) ){
        wp_die( esc_html__( 'What are you doing here ?', 'games' ) );
    }
 
    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
  
    // Check if $_POST field(s) are available
    if ( ! empty( $_POST['game_url'] ) ){
        update_post_meta( $post_id, 'game_url', esc_url_raw( $_POST['game_url'] ) );
    }
     
}
add_action( 'save_post_game', 'games_save_metabox' );
